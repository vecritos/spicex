# Agentctl State Machine Module
# Suggested install path: C:\Program Files\Agentctl\agentctl.psm1

$Script:AgentctlRoot = Join-Path ${env:ProgramFiles} "Agentctl"
$Script:StateFile = Join-Path $Script:AgentctlRoot "state.json"
$Script:Version = "1.0.0"

function Initialize-Agentctl {
    if (-not (Test-Path $Script:AgentctlRoot)) {
        New-Item -ItemType Directory -Path $Script:AgentctlRoot -Force | Out-Null
    }
    if (-not (Test-Path $Script:StateFile)) {
        $state = @{
            version = $Script:Version
            mode = "bootstrap"
            runtime = @{
                verbose = $false
            }
        }
        $state | ConvertTo-Json -Depth 5 | Set-Content -Path $Script:StateFile -Encoding UTF8
    }
}

function Get-AgentctlState {
    Initialize-Agentctl
    Get-Content $Script:StateFile -Raw | ConvertFrom-Json
}

function Set-AgentctlState {
    param(
        [Parameter(Mandatory)]
        [object]$State
    )
    $State | ConvertTo-Json -Depth 5 | Set-Content -Path $Script:StateFile -Encoding UTF8
}

function Set-AgentctlMode {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet("bootstrap","setup","operational","maintenance","disabled")]
        [string]$Mode
    )
    $state = Get-AgentctlState
    $state.mode = $Mode
    Set-AgentctlState -State $state
    Write-Output "agentctl mode set to '$Mode'"
}

function Get-AgentctlMode {
    (Get-AgentctlState).mode
}

function Set-AgentctlRuntime {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Key,
        [Parameter(Mandatory)]
        [object]$Value
    )
    $state = Get-AgentctlState
    $state.runtime.$Key = $Value
    Set-AgentctlState -State $state
    Write-Output "runtime setting '$Key' updated"
}

function Get-AgentctlRuntime {
    (Get-AgentctlState).runtime
}

function Invoke-Agentctl {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet("status","mode","runtime","help")]
        [string]$Command,
        [string]$Arg1,
        [string]$Arg2
    )

    switch ($Command) {
        "status" { Get-AgentctlState }
        "mode" {
            if ($Arg1) { Set-AgentctlMode -Mode $Arg1 }
            else { Get-AgentctlMode }
        }
        "runtime" {
            if ($Arg1 -and $Arg2) {
                Set-AgentctlRuntime -Key $Arg1 -Value $Arg2
            } else {
                Get-AgentctlRuntime
            }
        }
        "help" { Get-Help Invoke-Agentctl -Full }
    }
}

Export-ModuleMember -Function Initialize-Agentctl,Get-AgentctlState,Set-AgentctlMode,Get-AgentctlMode,Set-AgentctlRuntime,Get-AgentctlRuntime,Invoke-Agentctl