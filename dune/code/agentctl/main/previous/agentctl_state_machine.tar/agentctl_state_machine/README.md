# agentctl (State Machine)

PowerShell-based persistent state machine stored under Program Files.

## Install
Copy to:
C:\Program Files\Agentctl\

Import:
Import-Module "C:\Program Files\Agentctl\agentctl.psm1"

## Modes
bootstrap | setup | operational | maintenance | disabled

## Commands
Invoke-Agentctl status
Invoke-Agentctl mode
Invoke-Agentctl mode operational
Invoke-Agentctl runtime verbose true
Invoke-Agentctl help